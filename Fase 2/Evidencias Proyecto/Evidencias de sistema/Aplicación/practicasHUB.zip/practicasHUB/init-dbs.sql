CREATE DATABASE auth_db;
CREATE DATABASE practica_db;
CREATE DATABASE document_db;